#include <stdio.h>
#include<stdlib.h>
#include<string.h>

struct aviao
{

    char modelo[30];
    char fabricante[30];
    int passageiros;
    double comprimento;
    double altura;
    double velocidade;
    double altitude;
    char motor[30];
};

int main()
{

    int quanti_aviao;

    printf("DIGITE A QUATIDADE DE AVIAO QUE SERAO CADASTRADOS\n");
    scanf("%d",&quanti_aviao);
    printf(".....:::::ATENCAO!!!:::::.....\n");
    printf("AO INSERIR VALORES DECIMAIS UTILIZE O '.' AO INVES DA ','\n");

    struct aviao Cadastro[quanti_aviao];

    for (int i = 0; i < quanti_aviao; i++)
    {

        printf(":..INFORMACOES DA AERONAVE..:\n\n ",i+1);
        printf("DIGITE O MODELO DA AERONAVE:\n");
        scanf("%s",&Cadastro[i].modelo);
        printf("DIGITE O FABRICANTE DA AERONAVE\n");
        scanf("%s",&Cadastro[i].fabricante);
        printf("DIGITE A QUANTIDADE LIMITE DE PASSAGEIROS: \n");
        scanf("%d",&Cadastro[i].passageiros);
        printf("DIGITE O COMPRIMENTO DA AERONAVE\n");
        scanf("%lf",&Cadastro[i].comprimento);
        printf("DIGITE A ALTURA DA AERONAVE (EM METROS) \n");
        scanf("%lf",&Cadastro[i].altura);
        printf("DIGITE A VELOCIDADE MAXIMA QUE A AERONAVE PODE ATINGIR (EM KM/h) \n");
        scanf("%lf",&Cadastro[i].velocidade);
        printf("DIGITE A ALTITUDE MAXIMA QUE A AERONAVE PODE ATINGIR (EM PES 'ft') \n");
        scanf("%f",&Cadastro[i].altitude);
        printf("DIGITE O MODELO DO MOTOR DA AERONAVE: \n");
        scanf("%s",&Cadastro[i].motor);
    }
/// EXIBIR OS DADOS COLETADOS ;

    for(int i =0; i < quanti_aviao; i++)
    {
        printf(":..INFORMACOES DA AERONAVE..:\n ",i+1);
        printf("MODELO DA AERONAVE: %s\n", Cadastro[i].modelo);
        printf("FABRICANTE: %s\n", Cadastro[i].fabricante);
        printf("A QUANTIDADE LIMITE DE PASSAGEIROS: %d\n",Cadastro[i].passageiros);
        printf("ALTURA DA AERONAVE:%.2lf \n",Cadastro[i].altura);
        printf("ALTITUDE MAXIMA QUE A AERONAVE PODE ATINGIR (EM PES 'ft') :%.2lf \n",Cadastro[i].altura);
        printf("DIGITE A VELOCIDADE MAXIMA QUE A AERONAVE PODE ATINGIR: %.2lf \n",Cadastro[i].velocidade);
        printf("DIGITE O MODELO DO MOTOR DA AERONAVE: %s \n",Cadastro[i].motor);
    }
    return 0;
}



