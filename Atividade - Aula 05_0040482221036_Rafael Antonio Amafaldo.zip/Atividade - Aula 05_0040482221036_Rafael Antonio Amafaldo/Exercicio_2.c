#include <stdio.h>
#include<stdlib.h>
#include<string.h>


/// dados do cliente
struct identificacao
{
    int numero_pedi;
    char nome_cliente[50];
    int telefone;
};
struct endereco
{
    char logradouro[50];
    int numero;
    char bairro[50];
    char complemento[50];
};

/// itens do pedido
struct itens
{
    char sabor[50];
    char tamanho[50];
    int quantidade;
};
struct pagamento
{
    char forma_pagamen[50];
    double valor_pedido;
};

/// estrutura do pedido
struct Pedido
{
    int numero_pedi;
    char nome_cliente[50];
    int telefone;
    struct endereco endereco_entrega;
    struct itens item [20];
    struct pagamento pagamento_pedido;
};

/// programa principal
int main ()
{

    struct Pedido pedido1;
    printf(":::::::::::::::..........OLHA A PIZZA !!! ........:::::::::::::::::\n");
    printf(":::::::::::::::........::FACA SEU PEDIDO::........:::::::::::::::::\n");
    printf("Digite o numero do pedido:\n");
    scanf("%d",&pedido1.numero_pedi);
    printf("NOME DO CLIENTE:\n");
    scanf(" %[^\n]",pedido1.nome_cliente);
    printf("TELEFONE:\n");
    scanf("%d",&pedido1.telefone);
    printf("ENDERECO:\n");
    printf("LOGRADOURO:\n");
    scanf(" %[^\n]",&pedido1.endereco_entrega.logradouro);
    printf("NUMERO:\n");
    scanf("%d",&pedido1.endereco_entrega.numero);
    printf("COMPLEMENTO:\n");
    scanf(" %[^\n]",&pedido1.endereco_entrega.complemento);
    printf("BAIRRO:\n");
    scanf(" %[^\n]",&pedido1.endereco_entrega.bairro);


    int quanti_pedido=0;

    printf("DIGITE A QUANTIDADE DE ITENS DO PEDIDO:\n");
    scanf("%d",&quanti_pedido);// define a quantidade pode ser 10 ou mais ...

    printf("ADICIONE OS ITENS DO PEDIDO:\n");
    for (int i=0; i<quanti_pedido; i++)
    {
        printf("ITEM %d:\n",i+1);
        printf("SABOR:\n");
        scanf(" %[^\n]",&pedido1.item[i].sabor);
        printf("TAMANHO:\n");
        scanf(" %[^\n]",&pedido1.item[i].tamanho);
        printf("QUANTIDADE DE FATIAS\n");
        scanf("%d",&pedido1.item[i].quantidade);

    }
    printf("INFORME A FORMA DE PAGAMENTO:\n");
    scanf(" %[^\n]",&pedido1.pagamento_pedido.forma_pagamen);
    printf("INFORME O VALOR DO PEDIDO:\n");
    scanf("%lf",&pedido1.pagamento_pedido.valor_pedido);

    ///Exibir o pedido na tela
    printf("\nINFORMACOES DO CLIENTE:\n");
    printf("N�mero do Pedido: %d\n", pedido1.numero_pedi);
    printf("Nome do Cliente: %s\n", pedido1.nome_cliente);
    printf("Telefone: %d\n", pedido1.telefone);
    printf("ENDERECO DE ENTREGA:\n");
    printf("Logradouro: %s\n", pedido1.endereco_entrega.logradouro);
    printf("N�mero: %d\n", pedido1.endereco_entrega.numero);
    printf("Bairro: %s\n", pedido1.endereco_entrega.bairro);
    printf("Complemento: %s\n", pedido1.endereco_entrega.complemento);
    printf("\nINFORMACOES DO PRODUTO\n");

    ///la�o para exibir os itens de acordo com a quantidade
    for (int i = 0; i < quanti_pedido; i++)
    {
        printf("Item %d:\n", i + 1);
        printf("Sabor: %s\n", pedido1.item[i].sabor);
        printf("Tamanho: %s\n", pedido1.item[i].tamanho);
        printf("Quantidade: %i\n", pedido1.item[i].quantidade);
    }
    printf("\nINFORMACOES DE PAGAMENTO\n");
    printf("Forma de Pagamento: %s\n", pedido1.pagamento_pedido.forma_pagamen);
    printf("Valor do Pedido: %.2lf \n",pedido1.pagamento_pedido.valor_pedido);
    return 0;
}
