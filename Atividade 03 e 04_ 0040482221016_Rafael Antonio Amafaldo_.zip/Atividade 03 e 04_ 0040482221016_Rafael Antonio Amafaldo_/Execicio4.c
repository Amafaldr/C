#include <stdio.h>


void inverter_ptrs(int *ptr1, int *ptr2){

int temp = *ptr1;
*ptr1 = *ptr2;
*ptr2 = temp;

 }
 int main (){
 int num1 =10;
 int num2 =20;

 int *ptr1 = &num1;
 int *ptr2 = &num2;

 printf ("Valor das variaveis antes de inverter os valores:\t  num1 = %d, num2 = %d\n", *ptr1, *ptr2);
 inverter_ptrs(ptr1,ptr2);
 printf("Valor das variaveis apos a inversao dos valores:\t num1 = %d, num2 = %d\n", *ptr1, *ptr2);

 return 0;

 }
