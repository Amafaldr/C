#include <stdio.h>
#include <string.h>
#define TAMANHO_VETOR 5

int contarStringsComA(char *arrayDeStrings[], int tamanho) {
    int contador = 0;

    for (int i = 0; i < tamanho; i++) {
        if (arrayDeStrings[i][0] == 'A') {
            contador++;
        }
    }

    return contador;
}

int main() {
    char *strings[TAMANHO_VETOR] = {
        "Rafael",
        "Abacate",
        "Abacaxi",
        "Laranja",
        "Uva"
    };

    int stringsComA = contarStringsComA(strings, TAMANHO_VETOR);

    printf("N�mero de strings come�ando com 'A': %d\n", stringsComA);

    return 0;
}
