#include <stdio.h>

void multiplicador_vlr(int *ptr) {
    *ptr *= 2;

}

int main() {
    int numero = 99 ;
    int *ptr = &numero;

    printf("VALOR ANTES DE SER MULTIPLICADO %d\n",*ptr);
    multiplicador_vlr(ptr);
    printf("VALOR DEPOIS DE SER MULTIPLICADO %d\n", *ptr);

    return 0;
}

