#include <stdio.h>

double funcao_media(int*ptr, int tamanho){
int media =0;

for (int i =0; i< tamanho; i++){
    media += ptr[i];
}
return (double)media/tamanho;
}

int main (){

int valores[15]= {1,2,3,5,6,7,8,9,10,11,12,13,14,15};
int tamanho = sizeof(valores) / sizeof(valores[0]);

double calcular = funcao_media(valores, tamanho);

printf("%.2f\n", calcular);

return 0;

}
