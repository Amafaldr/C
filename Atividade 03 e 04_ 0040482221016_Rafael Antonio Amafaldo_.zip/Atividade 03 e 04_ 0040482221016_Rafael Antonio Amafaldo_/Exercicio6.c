#include <stdio.h>

int maior_elemento(int *array, int tamanho)
{
    if (tamanho <= 0 || array == NULL)
    {
        return -1;
    }


    int maior = array[0];

    for (int i =1; i < tamanho; i++)
    {
        if (array[i] > maior)
        {
            maior = array [i];
        }
    }
return maior;

}

int main (){

int numeros[] = {12,23,34,45,56,67,78,89,90};
int tamanho = sizeof(numeros)/sizeof(numeros[0]);

int maior = maior_elemento(numeros,tamanho);
printf("o maior elemento e: %d\t ", maior);

return 0;


}
