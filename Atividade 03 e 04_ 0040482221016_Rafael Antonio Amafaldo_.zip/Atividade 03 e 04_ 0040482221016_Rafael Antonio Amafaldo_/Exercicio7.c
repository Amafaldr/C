#include <stdio.h>
#include <stdlib.h>

void transposeMatrix(int **matrix, int tamanho)
{
    int temp;
    for (int i = 0; i < tamanho; i++)
    {
        for (int j = i + 1; j < tamanho; j++)
        {
            temp = matrix[i][j];
            matrix[i][j] = matrix[j][i];
            matrix[j][i] = temp;
        }
    }
}

int main()
{
    int tamanho;
    printf("DIGITE O TAMANHO DA MATRIZ QUADRADA:\n");
    scanf("%d", &tamanho);
    printf("DIGITE OS ELEMENTOS DA MATRIZ:\n");
    int **ptr_matrix = (int **)malloc(tamanho * sizeof(int *));
    for (int i = 0; i < tamanho; i++)
    {
        ptr_matrix[i] = (int *)malloc(tamanho * sizeof(int));
        for (int j = 0; j < tamanho; j++)
        {
            scanf("%d", &ptr_matrix[i][j]);
        }
    }
    printf("MATRIZ ORIGINAL:\n");
    for (int i = 0; i < tamanho; i++)
    {
        for (int j = 0; j < tamanho; j++)
        {
            printf("%d ", ptr_matrix[i][j]);
        }
        printf("\n");
    }

    transposeMatrix(ptr_matrix, tamanho);

    printf("MATRIZ TRANSPOSTA:\n");
    for (int i = 0; i < tamanho; i++)
    {
        for (int j = 0; j < tamanho; j++)
        {
            printf("%d ", ptr_matrix[i][j]);
        }
        printf("\n");
    }

    for (int i = 0; i < tamanho; i++)
    {
        free(ptr_matrix[i]);
    }
    free(ptr_matrix);

    return 0;
}
