#include <stdio.h>

void apontar_valor(int *p, int x){

*p = x;

}

int main(){

int valor = 0;

apontar_valor(&valor,5);

printf("%d", valor);


}
