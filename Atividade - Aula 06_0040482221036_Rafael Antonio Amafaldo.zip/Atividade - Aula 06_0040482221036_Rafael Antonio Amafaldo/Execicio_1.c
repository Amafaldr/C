#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct voo
{
    int numeroVoo[10];
    char dataVoo[11];
    char horaVoo[4];
    char aeroportoSaida[20];
    char aeroportoChegada[20];
    char rota[20];
    double tempoVoo;
    int quantidadePassageiros;
};

int main ()
{
    int quantidadeVoo;

    printf("....::::::: RIVERTRILL AIRLINES :::::::....\n");
    printf("INFORME OS DADOS DO VOO:\n");
    printf("QUANTIDADE DE VOOS QUE SERAO CADASTRADOS:\n");
    printf("DIGITE A QUANTIDADE DE VOOS:\n");
    scanf("%d", &quantidadeVoo);

    // Alocar mem�ria para os dados do voo

    struct voo *voos = (struct voo *)malloc(quantidadeVoo * sizeof(struct voo));

    for (int i = 0; i < quantidadeVoo; i++)
    {
        // Ler as informa��es do usu�rio

        printf("VOO %d\n", i+1);
        printf("DIGITE O(S) NUMERO(S) DO(S) VOO(S) :\n");
        scanf("%d", &voos[i].numeroVoo);
        printf("DIGITE A DATA DO VOO(DD/MM/AAAA)\n");
        scanf("%s",voos[i].dataVoo);
        printf("DIGITE A HORA DO VOO\n");
        scanf("%s",&voos[i].horaVoo);
        printf("DIGITE O LOCAL DA DECOLAGEM\n");
        scanf("%s",voos[i].aeroportoSaida);
        printf("DIGITE O LOCAL DA ATERRISSAGEM\n");
        scanf("%s",voos[i].aeroportoChegada);
        printf("DIGITE A ROTA DA VIAGEM\n");
        scanf("%s",voos[i].rota);
        printf("DIGITE O TEMPO ESTIMADO DE VOO( EM HORAS )\n");
        scanf("%lf",&voos[i].tempoVoo);
        printf("DIGITE A QUANTIDADE DE PASSAGEIROS\n");
        scanf("%d", &voos[i].quantidadePassageiros);
    }

    // Validar as entradas

    for (int i = 0; i < quantidadeVoo; i++)
    {
        if (voos[i].quantidadePassageiros < 0)
        {
            printf("O n�mero de passageiros n�o pode ser negativo.\n");
            exit(1);
        }
    }

    // Imprimir os dados dos voos

    for (int i = 0; i < quantidadeVoo; i++)
    {
        printf("NUMERO DO VOO: %d\n", voos[i].numeroVoo);
        printf("DATA DO VOO: %s\n", voos[i].dataVoo);
        printf("HORARIO DO VOO: %s\n", voos[i].horaVoo);
        printf("LOCAL DE DECOLAGEM: %s\n", voos[i].aeroportoSaida);
        printf("LOCAL DE ATERRISSAGEM: %s\n", voos[i].aeroportoChegada);
        printf("ROTA: %s\n", voos[i].rota);
        printf("TEMPO ESTIMADO DE VOO: %.2lf\n", voos[i].tempoVoo);
        printf("QUANTIDADE DE PASSAGEIROS: %d\n", voos[i].quantidadePassageiros);
    }

    // Liberar a mem�ria alocada

    free(voos);

    return 0;
}
